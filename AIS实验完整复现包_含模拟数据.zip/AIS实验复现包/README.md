# AIS实验方法与复现材料

数据全部为程序模拟，无下载的外部AIS数据。原始实验脚本保持不变。本包保存主实验及30组随机种子的完整数据，而非仅保存种子。详细方法、过程、结果及限制见包内PDF报告。

## 运行

原环境：CPython 3.12.14，Windows 11，仅标准库。解压后在本目录运行：

```text
python verify_archive.py
python run.py --out rerun_output
python verify_archive.py --rerun rerun_output
```

第一步校验原归档72个文件；第三步比较新旧文件字节。跨平台或Python版本运行可能改变environment.json，需区分环境差异与数值差异。本次2026-11-13重跑72个文件均完全一致，见verification.json。

## 数据与输出

- run_output/truth_events.csv：主实验6000条唯一事件。
- run_output/raw_deliveries.csv：主实验7034条投递，其中1034条额外重复。
- run_output/replicates/<seed>/：30个种子的真实保存数据；每组包含上述两种CSV，种子20261106至20261135是整数而非日期。
- generation_config.json、regions.json：参数和模拟矩形边界。
- early_snapshot.json、final_snapshot.json：快照截止、行数及规范化行哈希；按arrival_s <= arrival_cutoff_s从原始投递重建。
- factorial_results.csv：八种D/T/V处理组合的计数。
- replicate_metrics.csv：30组×2区域，共60行；oracle列实际写入已断言等于真值的对齐值，aligned_error在断言后固定记录为0。
- summary.json：统计、差异分配和12个规则案例。
- analysis_contract.json、answer_evidence.json：脚本构造的合同及结果关联，并非智能体生成或验证；llm_executed为false。
- environment.json、manifest.sha256.json：原环境及72个文件校验清单。

以上JSON与结果CSV均位于run_output。主实验数据与replicates/20261106内容相同，不是额外独立样本。原目录共73文件（含清单自身）。

## 字段

|字段|含义|
|---|---|
|event_id|唯一模拟事件编号|
|mmsi|SYNTH开头的合成身份，非真实MMSI|
|event_s|相对起点的事件秒数，无真实日期|
|lat / lon|纬度 / 经度|
|source|synthetic-v1|
|arrival_s|相对起点的到达秒数，仅投递表包含|
|delivery_id|投递编号，仅投递表包含|
|is_duplicate|重复生成标签，仅投递表包含；算法不依赖该标签去重|

CSV为UTF-8，逗号分隔，带表头。A为[122,122.1)×[30,30.1)，B为[122.1,122.2)×[30,30.1)，窗口为[7200,10800)秒。D表示按(mmsi,event_s)最早投递去重，T表示使用事件时间，V表示最终快照；关闭则分别不去重、使用到达时间、使用早期快照。快照筛选后先去重再选窗。

## 使用限制

本实验验证受控数据中的口径差异和预设规则，不是实际智能体或RAG实验。12/12为固定案例检查通过，不能作为智能体准确率。Shapley分配是历史辅助结果，不是报告当前创新点。简化比较函数未充分检查空值、输入可用性及所有转换条件，详见报告。
