"""Reproducible synthetic AIS contract experiment. Python standard library only.
Run: python run.py --out run_output
No LLM, real AIS, distributed engine, or external services are used.
"""
from __future__ import annotations
import argparse, csv, hashlib, itertools, json, math, platform, random, statistics
from collections import Counter
from pathlib import Path

CONFIG = dict(seed=20261106, ships=60, duration_seconds=21600,
              window_start=7200, window_end=10800, early_cutoff=11400,
              final_cutoff=28800, duplicate_probability=.18,
              delayed_probability=.15, replicates=30)

def dump(path, obj):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, ensure_ascii=False, sort_keys=True, indent=2)+'\n', encoding='utf-8')

def digest(obj):
    return hashlib.sha256(json.dumps(obj,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()).hexdigest()

def csvout(path, rows):
    rows=list(rows)
    with path.open('w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)

def region(row):
    # Toy polygons, half-open, no claim of a real sea boundary.
    if not 30 <= row['lat'] < 30.1: return 'OUT'
    if 122 <= row['lon'] < 122.1: return 'A'
    if 122.1 <= row['lon'] < 122.2: return 'B'
    return 'OUT'

def generate(seed):
    rng=random.Random(seed);truth=[];raw=[]
    for ship in range(CONFIG['ships']):
        # A has fewer vessels and more frequent reports; some vessels cross A/B.
        home='A' if ship<20 else 'B';interval=120 if home=='A' else 360
        offset=rng.randrange(interval)
        for t in range(offset,CONFIG['duration_seconds'],interval):
            side=home
            if ship%10==0 and (t//1800)%2: side='B' if home=='A' else 'A'
            lon=(122.025 if side=='A' else 122.125)+.01*math.sin(t/1800+ship)
            lat=30.05+.01*math.cos(t/2400+ship)
            uid=f'S{ship:03d}-{t:05d}'
            base=dict(event_id=uid,mmsi=f'SYNTH{ship:03d}',event_s=t,
                      lat=round(lat,7),lon=round(lon,7),source='synthetic-v1')
            truth.append(base)
            delay=rng.randint(1500,5400) if rng.random()<CONFIG['delayed_probability'] else rng.randint(0,90)
            # Emulated outage: selected ships' 01:00-02:00 messages arrive near 03:00.
            if ship%7==0 and 3600<=t<7200:delay=10800-t+rng.randint(0,120)
            first=dict(base,arrival_s=t+delay,delivery_id=uid+'-0',is_duplicate=0)
            raw.append(first)
            if rng.random()<CONFIG['duplicate_probability']:
                raw.append(dict(base,arrival_s=first['arrival_s']+rng.randint(1,240),
                                delivery_id=uid+'-1',is_duplicate=1))
    return truth,sorted(raw,key=lambda r:(r['arrival_s'],r['delivery_id']))

def compute(raw, fixes, metric='messages'):
    """Fixes: D=event-key dedup; T=event-time window; V=complete snapshot."""
    cutoff=CONFIG['final_cutoff'] if 'V' in fixes else CONFIG['early_cutoff']
    clock='event_s' if 'T' in fixes else 'arrival_s'
    seen=set();rows=[]
    for r in raw:
        if r['arrival_s']>cutoff:continue
        key=(r['mmsi'],r['event_s'])
        if 'D' in fixes:
            if key in seen:continue
            seen.add(key)
        if CONFIG['window_start']<=r[clock]<CONFIG['window_end'] and region(r)!='OUT':rows.append(r)
    return {a:(sum(region(r)==a for r in rows) if metric=='messages'
               else len({r['mmsi'] for r in rows if region(r)==a})) for a in ['A','B']}

def oracle(truth,metric):
    # Independent oracle uses unique event truth, never delivery/time-selection flags.
    selected=[r for r in truth if 7200<=r['event_s']<10800]
    if metric=='messages':return dict(Counter(region(r) for r in selected))
    return {a:len(set(r['mmsi'] for r in selected if region(r)==a)) for a in ['A','B']}

def factorial(raw):
    return {''.join(s):compute(raw,set(s)) for k in range(4) for s in itertools.combinations('DTV',k)}

def shapley(values):
    ans={a:{f:0.0 for f in 'DTV'} for a in ['A','B']}
    for order in itertools.permutations('DTV'):
        current=set()
        for f in order:
            before=''.join(sorted(current));current.add(f);after=''.join(sorted(current))
            for a in ans:ans[a][f]+=(values[after][a]-values[before][a])/6
    for a in ans:assert abs(sum(ans[a].values())-(values['DTV'][a]-values[''][a]))<1e-8
    return ans

CONTRACT=dict(population='AIS-visible synthetic vessels',metric='messages',unit='records',
    identity='mmsi+event_s',dedup='first_delivery',time_basis='event_s',
    window=[7200,10800],timezone='UTC',boundary='toy-v1',grid_role='index',
    index_resolution=7,snapshot='final',qc='v1',evidence_version='E1',
    source_fields=['mmsi','event_s','arrival_s','lat','lon'],input_available=True)

def compare(left,right):
    required=set(CONTRACT)-{'index_resolution'}
    missing=sorted(required-set(left)|required-set(right))
    if missing:return {'state':'INSUFFICIENT','reason':'missing_fields','fields':missing}
    changed=sorted(k for k in required if left[k]!=right[k])
    # Differences in estimand are not silently translated into one shared ranking.
    if any(k in changed for k in ['population','metric','unit']):
        return {'state':'NOT_COMPARABLE','reason':'different_estimand','fields':changed}
    if not changed:return {'state':'DIRECT','reason':'semantic_fields_equal','fields':[]}
    if not left['input_available'] or not right['input_available']:
        return {'state':'INSUFFICIENT','reason':'cannot_replay','fields':changed}
    needed={'mmsi','event_s','arrival_s','lat','lon'}
    if not needed.issubset(left['source_fields']) or not needed.issubset(right['source_fields']):
        return {'state':'INSUFFICIENT','reason':'lost_required_detail','fields':changed}
    return {'state':'RECOMPUTE','reason':'align_and_recheck','fields':changed}

def gates():
    cases=[('same',{},'DIRECT'),('index_only',{'index_resolution':6},'DIRECT'),
      ('arrival_clock',{'time_basis':'arrival_s'},'RECOMPUTE'),
      ('no_dedup',{'dedup':'none'},'RECOMPUTE'),('early',{'snapshot':'early'},'RECOMPUTE'),
      ('boundary',{'boundary':'toy-v2'},'RECOMPUTE'),('qc',{'qc':'v2'},'RECOMPUTE'),
      ('evidence',{'evidence_version':'E2'},'RECOMPUTE'),
      ('ships_vs_messages',{'metric':'ships','unit':'vessels'},'NOT_COMPARABLE'),
      ('whole_population',{'population':'all vessels'},'NOT_COMPARABLE'),
      ('aggregates_only',{'source_fields':['count'],'time_basis':'arrival_s'},'INSUFFICIENT'),
      ('missing_snapshot',{'snapshot':None},'INSUFFICIENT')]
    rows=[]
    for name,patch,expected in cases:
        c=dict(CONTRACT);c.update(patch)
        if c.get('snapshot') is None:c.pop('snapshot')
        actual=compare(CONTRACT,c)
        rows.append(dict(case=name,expected=expected,actual=actual['state'],passed=actual['state']==expected,detail=actual))
    assert all(r['passed'] for r in rows)
    return rows

def main(out):
    out.mkdir(parents=True,exist_ok=True)
    truth,raw=generate(CONFIG['seed'])
    csvout(out/'truth_events.csv',truth);csvout(out/'raw_deliveries.csv',raw)
    dump(out/'generation_config.json',CONFIG)
    dump(out/'regions.json',{'crs':'EPSG:4326','boundary':'toy-v1','A':[122,30,122.1,30.1],'B':[122.1,30,122.2,30.1],'closure':'left closed right open','real_geographic_claim':False})
    values=factorial(raw);attrib=shapley(values)
    assert values['DTV']==oracle(truth,'messages')
    assert compute(raw,set('DTV'),'ships')==oracle(truth,'ships')
    assert compute(raw,set('TV'),'ships')==compute(raw,set('DTV'),'ships')
    # Replay an identical delivery stream: idempotent result is unchanged.
    assert compute(raw+raw,set('DTV'))==values['DTV']
    # Region union distinct count differs from sum when ships cross boundaries.
    union=len({r['mmsi'] for r in truth if 7200<=r['event_s']<10800 and region(r)!='OUT'})
    ships=compute(raw,set('DTV'),'ships')
    summary={'unique_events':len(truth),'deliveries':len(raw),'duplicate_deliveries':len(raw)-len(truth),
             'baseline':values[''],'aligned':values['DTV'],'oracle':oracle(truth,'messages'),
             'distinct_ships_by_region':ships,'union_distinct_ships':union,
             'factorial':values,'shapley':attrib,'gate_cases':gates()}
    reps=[]
    # Every replicate's actual inputs are archived, not only its seed.
    for i in range(CONFIG['replicates']):
        seed=CONFIG['seed']+i;t,r=generate(seed);v=factorial(r);s=shapley(v)
        rd=out/'replicates'/str(seed);rd.mkdir(parents=True,exist_ok=True)
        csvout(rd/'truth_events.csv',t);csvout(rd/'raw_deliveries.csv',r)
        assert v['DTV']==oracle(t,'messages')
        for a in ['A','B']:
            reps.append(dict(seed=seed,region=a,baseline=v[''][a],oracle=v['DTV'][a],
                absolute_relative_error=abs(v[''][a]-v['DTV'][a])/v['DTV'][a],
                aligned_error=0,attribution_D=s[a]['D'],attribution_T=s[a]['T'],attribution_V=s[a]['V']))
    csvout(out/'replicate_metrics.csv',reps)
    summary['replicates']={a:{'mean_naive_absolute_relative_error':statistics.mean(x['absolute_relative_error'] for x in reps if x['region']==a),
         'min_naive_absolute_relative_error':min(x['absolute_relative_error'] for x in reps if x['region']==a),
         'max_naive_absolute_relative_error':max(x['absolute_relative_error'] for x in reps if x['region']==a)} for a in ['A','B']}
    dump(out/'summary.json',summary)
    csvout(out/'factorial_results.csv',[dict(fixes=k or 'NONE',A=v['A'],B=v['B']) for k,v in values.items()])
    for name,cutoff in [('early',CONFIG['early_cutoff']),('final',CONFIG['final_cutoff'])]:
        rows=[r for r in raw if r['arrival_s']<=cutoff]
        dump(out/(name+'_snapshot.json'),{'snapshot':name,'arrival_cutoff_s':cutoff,'row_count':len(rows),'rows_hash':digest(rows),'raw_file':'raw_deliveries.csv'})
    contract=dict(CONTRACT);contract['source_sha256']=hashlib.sha256((out/'raw_deliveries.csv').read_bytes()).hexdigest()
    dump(out/'analysis_contract.json',contract)
    dump(out/'answer_evidence.json',{'request_id':'toy-request-001','contract_id':digest(contract),
         'result':values['DTV'],'metric':'messages','unit':'records','evidence':['factorial_results.csv','analysis_contract.json','final_snapshot.json'],
         'oracle_equal':True,'llm_executed':False,'interpretation':'Synthetic reporting counts, not ship abundance or real maritime risk.'})
    dump(out/'environment.json',{'python':platform.python_version(),'implementation':platform.python_implementation(),'platform':platform.platform(),'dependencies':'standard library only'})
    manifest={str(p.relative_to(out)).replace('\\','/'):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(out.rglob('*')) if p.is_file() and p.name!='manifest.sha256.json'}
    dump(out/'manifest.sha256.json',manifest)
    print(json.dumps({k:v for k,v in summary.items() if k!='gate_cases'},ensure_ascii=False,indent=2))

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--out',type=Path,default=Path(__file__).resolve().parent/'run_output')
    main(parser.parse_args().out)
