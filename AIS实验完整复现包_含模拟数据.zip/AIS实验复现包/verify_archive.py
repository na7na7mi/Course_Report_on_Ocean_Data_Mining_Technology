"""Check original archived inputs/outputs; optionally compare a fresh rerun."""
import argparse, hashlib, json
from pathlib import Path
p=argparse.ArgumentParser()
p.add_argument('--rerun',type=Path)
args=p.parse_args()
base=Path(__file__).resolve().parent/'run_output'
manifest=json.loads((base/'manifest.sha256.json').read_text(encoding='utf-8'))
bad=[n for n,h in manifest.items() if not (base/n).is_file() or hashlib.sha256((base/n).read_bytes()).hexdigest()!=h]
print('Archived files checked:',len(manifest),'Failures:',bad)
if bad:raise SystemExit(1)
if args.rerun:
    differences=[n for n in manifest if not (args.rerun/n).is_file() or (base/n).read_bytes()!=(args.rerun/n).read_bytes()]
    print('Rerun byte differences:',differences)
    if differences:raise SystemExit(2)
